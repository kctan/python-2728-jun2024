import os

def rename_folders(directory):
    for item in os.listdir(directory):
        item_path = os.path.join(directory, item)
        
        if os.path.isdir(item_path):
            # Check if the folder name starts with 8 digits and an underscore
            if len(item) > 9 and item[:8].isdigit() and item[8] == '_':
                new_name = item[9:]  # Remove the 8 digits and the underscore
                new_path = os.path.join(directory, new_name)
                os.rename(item_path, new_path)
                item_path = new_path  # Update item_path after renaming

            # Check if the folder is empty
            if not os.listdir(item_path):
                parent_directory = os.path.basename(directory)
                new_name = f"{item_path.split(os.sep)[-1]}_EMPTY"
                new_path = os.path.join(directory, new_name)
                os.rename(item_path, new_path)

# Usage
directory = '.'  # Replace with the path to your directory
rename_folders(directory)
